package com.example.bsbot

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.random.Random

/**
 * "Мозг": ищет полоски здоровья (зелёная = ты, красные = враги) и решает, что делать.
 * Если в твоей версии игры цвета другие - правь isRed / isGreen.
 */
object Brain {
    class Pt(val x: Float, val y: Float)
    class Frame(val me: Pt?, val enemies: List<Pt>)
    class Action(val joy: FloatArray?, val taps: List<FloatArray>)

    private const val STEP = 3

    private fun isRed(c: Int): Boolean {
        val r = c shr 16 and 255; val g = c shr 8 and 255; val b = c and 255
        return r > 200 && g < 80 && b < 90
    }
    private fun isGreen(c: Int): Boolean {
        val r = c shr 16 and 255; val g = c shr 8 and 255; val b = c and 255
        return g > 190 && r < 120 && b < 110
    }

    fun analyze(bmp: Bitmap): Frame {
        val w = bmp.width; val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val gw = w / STEP; val gh = h / STEP
        val red = BooleanArray(gw * gh); val green = BooleanArray(gw * gh)
        for (gy in 0 until gh) for (gx in 0 until gw) {
            val c = px[gy * STEP * w + gx * STEP]
            if (isRed(c)) red[gy * gw + gx] = true
            else if (isGreen(c)) green[gy * gw + gx] = true
        }
        val bodyOffset = h * 0.07f
        val foes = components(red, gw, gh).map { Pt(it.x * STEP, it.y * STEP + bodyOffset) }
        val mine = components(green, gw, gh).map { Pt(it.x * STEP, it.y * STEP + bodyOffset) }
        return Frame(mine.firstOrNull(), foes)
    }

    /** Связные области формы "полоска" (широкая и низкая). Возвращает центры. */
    private fun components(mask: BooleanArray, gw: Int, gh: Int): List<Pt> {
        val seen = BooleanArray(mask.size)
        val out = ArrayList<Pt>()
        val stack = IntArray(mask.size)
        for (i in mask.indices) {
            if (!mask[i] || seen[i]) continue
            var sp = 0; stack[sp++] = i; seen[i] = true
            var minX = gw; var maxX = 0; var minY = gh; var maxY = 0
            while (sp > 0) {
                val cur = stack[--sp]
                val x = cur % gw; val y = cur / gw
                minX = minOf(minX, x); maxX = max(maxX, x); minY = minOf(minY, y); maxY = max(maxY, y)
                for (d in intArrayOf(-1, 1, -gw, gw)) {
                    val n = cur + d
                    if (n < 0 || n >= mask.size) continue
                    if (d == -1 && x == 0) continue
                    if (d == 1 && x == gw - 1) continue
                    if (mask[n] && !seen[n]) { seen[n] = true; stack[sp++] = n }
                }
            }
            val bw = maxX - minX + 1; val bh = maxY - minY + 1
            if (bw >= 7 && bh in 1..9 && bw > 1.8f * bh)
                out.add(Pt((minX + maxX) / 2f, maxY.toFloat()))
        }
        return out
    }

    // ---- решения ----
    private var strafeSign = 1
    private var strafeUntil = 0L
    private var lastSuper = 0L

    fun decide(f: Frame, sw: Int, sh: Int): Action {
        val joyC = floatArrayOf(sw * JOY_X, sh * JOY_Y)
        val atk = floatArrayOf(sw * ATK_X, sh * ATK_Y)
        val sup = floatArrayOf(sw * SUP_X, sh * SUP_Y)
        val rad = sh * 0.11f
        val now = System.currentTimeMillis()
        val me = f.me ?: return Action(null, emptyList())

        if (now > strafeUntil) {                 // меняем сторону стрейфа непредсказуемо
            strafeSign = if (Random.nextBoolean()) 1 else -1
            strafeUntil = now + Random.nextLong(500, 1400)
        }

        val foe = f.enemies.minByOrNull { hypot(it.x - me.x, it.y - me.y) }
        if (foe == null) {                        // врагов не видно - идём вперёд с рысканием
            val a = Random.nextFloat() * 0.8f - 0.4f
            return Action(floatArrayOf(joyC[0], joyC[1], joyC[0] + a * rad, joyC[1] - rad), emptyList())
        }

        val dx = foe.x - me.x; val dy = foe.y - me.y
        val dist = hypot(dx, dy).coerceAtLeast(1f)
        val ux = dx / dist; val uy = dy / dist
        val far = sh * 0.46f; val near = sh * 0.22f

        var mx: Float; var my: Float
        when {
            dist > far -> { mx = ux; my = uy }                       // сближаемся
            dist < near -> { mx = -ux; my = -uy }                    // отходим
            else -> { mx = -uy * strafeSign; my = ux * strafeSign }  // стрейф по кругу
        }
        // небольшая примесь стрейфа даже при сближении/отходе - сложнее попасть
        if (dist > near && dist <= far * 1.4f) { mx += -uy * strafeSign * 0.35f; my += ux * strafeSign * 0.35f }
        val len = hypot(mx, my).coerceAtLeast(0.001f)
        val joy = floatArrayOf(joyC[0], joyC[1], joyC[0] + mx / len * rad, joyC[1] + my / len * rad)

        val taps = ArrayList<FloatArray>()
        if (dist < sh * 0.6f) taps.add(atk)                           // атака автонаводится
        if (dist < sh * 0.42f && now - lastSuper > 4000 && Random.nextFloat() < 0.35f) {
            taps.add(sup); lastSuper = now
        }
        return Action(joy, taps)
    }

    // Координаты кнопок в долях экрана (landscape). КАЛИБРУЙ под свой телефон!
    const val JOY_X = 0.13f; const val JOY_Y = 0.72f
    const val ATK_X = 0.86f; const val ATK_Y = 0.76f
    const val SUP_X = 0.78f; const val SUP_Y = 0.88f
    // Лобби: кнопка "Играть" и "Продолжить" после боя
    const val PLAY_X = 0.88f; const val PLAY_Y = 0.90f
    const val NEXT_X = 0.50f; const val NEXT_Y = 0.92f
}
