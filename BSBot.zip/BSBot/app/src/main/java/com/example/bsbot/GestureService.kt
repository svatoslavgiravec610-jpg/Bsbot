package com.example.bsbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/** Делает мультитач: джойстик + тапы одновременно. */
class GestureService : AccessibilityService() {

    companion object {
        @Volatile var instance: GestureService? = null
        @Volatile var busy = false
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** Двигаем джойстик (если joy != null) и одновременно жмём taps. */
    fun act(joy: FloatArray?, taps: List<FloatArray>, durMs: Long) {
        if (busy) return
        val b = GestureDescription.Builder()
        var strokes = 0
        if (joy != null) {
            val p = Path().apply { moveTo(joy[0], joy[1]); lineTo(joy[2], joy[3]) }
            b.addStroke(StrokeDescription(p, 0, durMs)); strokes++
        }
        for (t in taps) {
            val p = Path().apply { moveTo(t[0], t[1]); lineTo(t[0] + 1f, t[1] + 1f) }
            b.addStroke(StrokeDescription(p, 20, 60)); strokes++
        }
        if (strokes == 0) return
        busy = true
        val ok = dispatchGesture(b.build(), object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { busy = false }
            override fun onCancelled(g: GestureDescription?) { busy = false }
        }, null)
        if (!ok) busy = false
    }
}
