package com.example.bsbot

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            if (r.resultCode == Activity.RESULT_OK && r.data != null) {
                val i = Intent(this, CaptureService::class.java)
                    .putExtra("code", r.resultCode).putExtra("data", r.data)
                ContextCompat.startForegroundService(this, i)
                // запускаем Brawl Stars
                packageManager.getLaunchIntentForPackage("com.supercell.brawlstars")?.let { startActivity(it) }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(48, 48, 48, 48)
        }
        root.addView(TextView(this).apply {
            text = "BS Bot\n\n1) Включи службу жестов\n2) Нажми СТАРТ — бот откроет игру и начнёт играть\n3) Игра должна быть в горизонтальном режиме"
            textSize = 16f
        })
        fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t; setOnClickListener { onClick() }; root.addView(this)
        }
        btn("1. Включить службу жестов") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("2. СТАРТ") {
            if (GestureService.instance == null) {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } else {
                val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projectionLauncher.launch(mpm.createScreenCaptureIntent())
            }
        }
        btn("СТОП") { startService(Intent(this, CaptureService::class.java).setAction("STOP")) }
        setContentView(root)
    }
}
