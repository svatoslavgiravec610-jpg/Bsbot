package com.example.bsbot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager

class CaptureService : Service() {
    @Volatile private var running = false
    private var projection: MediaProjection? = null
    private var thread: Thread? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") { stopSelf(); return START_NOT_STICKY }

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("bot", "Bot", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "bot").setContentTitle("BS Bot работает")
            .setSmallIcon(android.R.drawable.ic_media_play).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)

        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() {}, null)

        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        val w = dm.widthPixels; val h = dm.heightPixels
        val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        projection!!.createVirtualDisplay("bs", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, null)

        running = true
        thread = Thread { loop(reader, w, h) }.also { it.start() }
        return START_NOT_STICKY
    }

    private fun loop(reader: ImageReader, w: Int, h: Int) {
        var idle = 0
        var lastLobbyTap = 0L
        var step = 0
        while (running) {
            try {
                val img = reader.acquireLatestImage()
                if (img == null) { Thread.sleep(40); continue }
                val pl = img.planes[0]
                val stride = pl.rowStride / pl.pixelStride
                val raw = Bitmap.createBitmap(stride, h, Bitmap.Config.ARGB_8888)
                raw.copyPixelsFromBuffer(pl.buffer)
                img.close()
                val bmp = Bitmap.createBitmap(raw, 0, 0, w, h)
                raw.recycle()

                val frame = Brain.analyze(bmp)
                bmp.recycle()
                val gs = GestureService.instance ?: run { Thread.sleep(300); null } ?: continue

                if (frame.me != null) {
                    idle = 0
                    val a = Brain.decide(frame, w, h)
                    gs.act(a.joy, a.taps, 220)
                } else {
                    idle++
                    val now = System.currentTimeMillis()
                    if (idle > 8 && now - lastLobbyTap > 1800) {      // не в бою: лобби/результаты
                        lastLobbyTap = now
                        val p = if (step++ % 2 == 0) floatArrayOf(w * Brain.PLAY_X, h * Brain.PLAY_Y)
                                else floatArrayOf(w * Brain.NEXT_X, h * Brain.NEXT_Y)
                        gs.act(null, listOf(p), 80)
                    }
                }
                Thread.sleep(60)
            } catch (e: InterruptedException) { break } catch (e: Exception) { Thread.sleep(200) }
        }
    }

    override fun onDestroy() {
        running = false
        thread?.interrupt()
        projection?.stop()
        super.onDestroy()
    }
}
